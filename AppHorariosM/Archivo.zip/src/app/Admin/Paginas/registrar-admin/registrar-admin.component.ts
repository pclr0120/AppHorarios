import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrar-admin',
  templateUrl: './registrar-admin.component.html',
  styleUrls: ['./registrar-admin.component.css']
})
export class RegistrarAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

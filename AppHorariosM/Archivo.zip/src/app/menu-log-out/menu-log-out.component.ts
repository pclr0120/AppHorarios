import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-log-out',
  templateUrl: './menu-log-out.component.html',
  styleUrls: ['./menu-log-out.component.css']
})
export class MenuLogOutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
